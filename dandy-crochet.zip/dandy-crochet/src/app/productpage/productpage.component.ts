import {Component} from '@angular/core';
import {Product} from "../../models/product.model";
import {DatabaseService} from "../../service/database.service";
import {ActivatedRoute, Router} from "@angular/router";
import {Cart} from "../../models/cart.model";

@Component({
  selector: 'app-productpage',
  templateUrl: './productpage.component.html',
  styleUrls: ['./productpage.component.css']
})
export class ProductpageComponent {
  product: Product = new Product("", 0, "", "", "");
  selectedQuantity: number = 1;


  cart: Cart = new Cart(1,"", 0, 0, 0, "", "", 0, 0);



  selectedSize: string = "";
  errorMsg: string = "";

  constructor(private database: DatabaseService,
              private acRoute: ActivatedRoute, private router: Router) {
  }

  ngOnInit() {
    let id = this.acRoute.snapshot.paramMap.get('id');
    console.log(id);
    this.database.selectProduct(id).then((data) => {
      this.product = data;
      console.log(this.product);
    }).catch((err) => {
      console.log("error: " + err);
      this.errorMsg = err;
    });


  }

  increment() {
    if (this.selectedQuantity < 10) {
      this.selectedQuantity++;
    }
  }

  decrement() {
    if (this.selectedQuantity > 1) {
      this.selectedQuantity--;
    }
  }

  btnAddToCart_click(product: Product) {
    //if the user has not selected quantity and size tell them
    if (!this.selectedQuantity || !this.selectedSize) {
      alert("Please select size and quantity before adding to cart.");
    } else {
      //otherwise add the values of their selection to the cart object
      this.cart = new Cart(product.id,product.productName, product.price, this.selectedQuantity, product.price * this.selectedQuantity, this.selectedSize, product.imageSrc, product.id, 0);

      console.log(this.cart);
      this.database.insertCart(this.cart)
        .then((data) => {
          alert("Product added to cart successfully!");
        }).catch((err) => {
        alert(err);
      })

    }

    this.router.navigate([`/cart`]);

  }


}
