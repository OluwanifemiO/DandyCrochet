import { Component } from '@angular/core';
import {DatabaseService} from "../service/database.service";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'dandycrochet';

  constructor(private database: DatabaseService) {
  }

  ngOnInit() {
    //this.database.clearDB();
    this.database.initDB();
  }


}
