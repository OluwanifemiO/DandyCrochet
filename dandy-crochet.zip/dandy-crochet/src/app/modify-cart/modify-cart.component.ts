import { Component } from '@angular/core';
import {DatabaseService} from "../../service/database.service";
import {ActivatedRoute, Router} from "@angular/router";
import {Product} from "../../models/product.model";
import {Cart} from "../../models/cart.model";


@Component({
  selector: 'app-modify-cart',
  templateUrl: './modify-cart.component.html',
  styleUrls: ['./modify-cart.component.css']
})
export class ModifyCartComponent {

  product: Product = new Product("", 0, "", "", "");
  selectedQuantity: number = 1;

  selectedSize: string = "";

  cart: Cart = new Cart(1, "", 0, this.selectedQuantity, 0, this.selectedSize, "", 0, 0);
  errorMsg: string = "";

  constructor(private database:DatabaseService, private router:Router, private acRoute: ActivatedRoute,) {
  }

  itemId:any = null;
  ngOnInit() {
    this.itemId = this.acRoute.snapshot.paramMap.get('id');
    console.log(this.itemId);
    // this.database.selectProduct(itemId).then((data) => {
    //   this.cart = data;
    //   console.log(this.cart);
    // }).catch((err) => {
    //   console.log("error: " + err);
    //   this.errorMsg = err;
    // });

    this.database.selectCart(this.itemId).then((data) => {
      this.cart = data;
      console.log(this.cart);
    }).catch((err) => {
      console.log("error: " + err);
      this.errorMsg = err;
    });

    if (localStorage.getItem('add-update-button')) {
      const updateButtonContainer = document.getElementById('update-btn-container');
      const updateButton = document.createElement('button');
      updateButton.textContent = 'Update';
      updateButton.className = 'btn btn-primary btn-sm me-3';
      updateButton.addEventListener('click', this.btnUpdateCart_click.bind(this));
      updateButtonContainer!.appendChild(updateButton);
      localStorage.removeItem('add-update-button');
    }

  }

  increment() {
    if (this.selectedQuantity < 10) {
      this.selectedQuantity++;
    }
  }

  decrement() {
    if (this.selectedQuantity > 1) {
      this.selectedQuantity--;
    }
  }


  btnUpdateCart_click(){
    console.log("newly selected quantity and size: ", this.selectedQuantity, this.selectedSize);
    this.cart.quantity = this.selectedQuantity;
    this.cart.size = this.selectedSize;
    this.cart.totalAmount = this.cart.price * this.selectedQuantity;

    this.cart = new Cart(this.cart.id, this.cart.productName, this.cart.price, this.cart.quantity, this.cart.totalAmount, this.cart.size, this.cart.imageSrc, this.cart.productId, 0);
    console.log(this.cart);
    this.database.updateCart(this.cart)
      .then((data) => {
        alert("Cart updated successfully!");
      }).catch((err) => {
      alert(err);
    })

    this.router.navigate([`/cart`]);

  }

}
