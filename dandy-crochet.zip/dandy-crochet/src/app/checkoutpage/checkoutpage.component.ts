import {Component, NgModule, ElementRef} from '@angular/core';
import {Customer} from "../../models/customer.model";
import {DatabaseService} from "../../service/database.service";
import {NgForm} from "@angular/forms";
import {Router} from "@angular/router";
import {Order} from "../../models/order.model";
import {Cart} from "../../models/cart.model";

@Component({
  selector: 'app-checkoutpage',
  templateUrl: './checkoutpage.component.html',
  styleUrls: ['./checkoutpage.component.css']
})
export class CheckoutpageComponent {
  customerInfo: Customer = new Customer("", "", "", "", "", "", "", "");
  order:Order = new Order(0,0,"", "");
  customerData: any;

  customers: Customer[] = [];
  carts: Cart[] = []

  constructor(private database: DatabaseService, private elementRef: ElementRef, private router: Router) {
  }

  ngOnInit() {

    this.database.selectAllCustomer()
      .then((data) => {
        console.log("Records retrieved successfully");
        this.customers = data;
        console.log(this.customers);
      })
      .catch((error) => {
        alert(error);
      });

    this.database.selectAllCart()
      .then((data) => {
        console.log("Records retrieved successfully");
        this.carts = data;
        console.log(this.carts);
      })
      .catch((error) => {
        alert(error);
      });
  }

  btnContinueToPayment_click(customerForm: NgForm) {
    if (customerForm.valid) {
      console.log("Customer Form is valid.");

      this.customerData = customerForm.value;
      console.log(this.customerData.fullName);
      this.customerInfo = new Customer(this.customerData.fullName, this.customerData.address, this.customerData.email, this.customerData.phone, this.customerData.city, this.customerData.province, this.customerData.postalCode, this.customerData.country);
      console.log(this.customerInfo);
      this.database.insertCustomer(this.customerInfo)
        .then((data) => {
          alert("Customer added successfully.");
        })
        .catch((error) => {
          alert(error.message);
        });

      for (let cartItem of this.carts) {
        this.database.updateCartCustomerId(this.customerInfo.id, cartItem.id)
          .then((data) => {
            console.log("customer id updated successfully.");
          })
          .catch((error) => {
            alert(error.message);
          });
      }
      const paymentForm = this.elementRef.nativeElement.querySelector('#paymentForm');
      paymentForm.scrollIntoView({behavior: 'smooth'});
    } else {
      console.log("Customer Form is invalid.");
    }
  }


  btnCheckout_click() {
    // Get the cart items and customer information
    const customerAddress = this.customerInfo.address + ',' + this.customerInfo.city + ',' + this.customerInfo.postalCode + ',' +this.customerInfo.province + ' ' + this.customerInfo.country
    for(let cartItem of this.carts){
      this.order = new Order(cartItem.id, cartItem.totalAmount, customerAddress, cartItem.productName);
      console.log(this.order);
      this.database.insertOrder(this.order)
        .then((data) => {
          alert("Order record inserted successfully.");
        })
        .catch((error) => {
          alert(error.message);
        });
    }

    console.log(this.order);
    this.router.navigate(['/orderinfo']);

  }

}
