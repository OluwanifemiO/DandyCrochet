import { Component } from '@angular/core';
import {Product} from "../../models/product.model";
import {DatabaseService} from "../../service/database.service";
import {Router} from "@angular/router";
import {Cart} from "../../models/cart.model";

@Component({
  selector: 'app-cartpage',
  templateUrl: './cartpage.component.html',
  styleUrls: ['./cartpage.component.css']
})
export class CartpageComponent {
//product:Product ;
cart:Cart[]=[];

constructor(private database:DatabaseService, private router:Router) {
}

ngOnInit(){
  this.database.selectAllCart()
    .then((data)=>{
      console.log(data);
      this.cart = data;
    })
    .catch((err)=>{
      console.log(err);
    })
}

getTotalAmount(){
  let totalAmount = 0;
  for(let cartItem of this.cart){
    totalAmount += cartItem.totalAmount;
  }
  return totalAmount.toFixed(2);
}

  btnUpdate_click(cart:Cart){
    this.router.navigate([`/modify/${cart.id}`]);

    localStorage.setItem('add-update-button', 'true');
  }

  btnDelete_click(cart:Cart){
    this.database.deleteCart(cart)
      .then((data)=>{
        this.ngOnInit();
      })
      .catch((err)=>{
        alert("Error in delete Cart: " + err);
      });
  }

  btnRedirectToCheckout_click(){
    this.router.navigate([`/checkout`]);
  }
}
