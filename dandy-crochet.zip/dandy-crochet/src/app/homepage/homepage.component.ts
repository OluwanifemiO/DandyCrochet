import {Component, NgModule} from '@angular/core';
import {DatabaseService} from "../../service/database.service";
import {Product} from "../../models/product.model";
import {Router} from "@angular/router";
import {ActivatedRoute} from "@angular/router";

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent {

  products:Product[] = [];
  errorMsg:string = "";
  constructor(private database:DatabaseService,
              private acRoute:ActivatedRoute, private router:Router) {
  }


  ngOnInit(){
    this.database.selectAllProduct()
      .then((data)=>{
        console.log(data);
        this.products = data;
      })
      .catch((err)=>{
        console.log(err);
      })


    // let id = this.acRoute.snapshot.paramMap.get('id');
    // console.log(id);
    // this.database.selectProduct(id).then((data)=>{
    //   this.products = data;
    // }).catch((err)=>{
    //   console.log("error: " +err);
    //   this.errorMsg = err;
    // })
  }

  redirectToProduct(product:Product){
    console.log("hi!")
    this.router.navigate([`/product/${product.id}`]);
  }

}
