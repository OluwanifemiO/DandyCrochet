import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomepageComponent } from './homepage/homepage.component';
import { CartpageComponent } from './cartpage/cartpage.component';
import { CheckoutpageComponent } from './checkoutpage/checkoutpage.component';
import { OrderinfopageComponent } from './orderinfopage/orderinfopage.component';
import { AboutpageComponent } from './aboutpage/aboutpage.component';
import { ProductpageComponent } from './productpage/productpage.component';
import {ModifyCartComponent} from "./modify-cart/modify-cart.component";


const routes: Routes = [
  {path:"home", component:HomepageComponent},
  {path:"cart", component:CartpageComponent},
  {path:"checkout", component:CheckoutpageComponent},
  {path:"orderinfo", component:OrderinfopageComponent},
  {path:"product/:id", component:ProductpageComponent},
  {path:"modify/:id", component:ModifyCartComponent},
  {path:"about", component:AboutpageComponent},
  {path:"",redirectTo:"/home",pathMatch:"full"}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
