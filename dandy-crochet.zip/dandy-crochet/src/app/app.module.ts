import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomepageComponent } from './homepage/homepage.component';
import { CartpageComponent } from './cartpage/cartpage.component';
import { CheckoutpageComponent } from './checkoutpage/checkoutpage.component';
import { OrderinfopageComponent } from './orderinfopage/orderinfopage.component';
import { AboutpageComponent } from './aboutpage/aboutpage.component';
import { NavComponent } from './nav/nav.component';
import { FooterComponent } from './footer/footer.component';
import { ProductpageComponent } from './productpage/productpage.component';
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import { ModifyCartComponent } from './modify-cart/modify-cart.component';

@NgModule({
  declarations: [
    AppComponent,
    HomepageComponent,
    CartpageComponent,
    CheckoutpageComponent,
    OrderinfopageComponent,
    AboutpageComponent,
    NavComponent,
    FooterComponent,
    ProductpageComponent,
    ModifyCartComponent
  ],
    imports: [
        BrowserModule,
        AppRoutingModule,
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule
    ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
