import { Component } from '@angular/core';
import {DatabaseService} from "../../service/database.service";
import {Cart} from "../../models/cart.model";
import {Customer} from "../../models/customer.model";
import {Order} from "../../models/order.model";

@Component({
  selector: 'app-orderinfopage',
  templateUrl: './orderinfopage.component.html',
  styleUrls: ['./orderinfopage.component.css']
})
export class OrderinfopageComponent {

orders:Order[] = [];

  constructor(private database:DatabaseService) {
  }

  ngOnInit(){

    this.database.selectAllOrder()
      .then((data)=>{
        console.log("Records retrieved successfully");
        this.orders = data;
          console.log(this.orders)
      })
      .catch((error)=>{
        alert(error);
      });


  }

  getTotalAmount(){
    let totalAmount = 0;
    for(let order of this.orders){
      totalAmount += order.totalAmount;
    }
    return totalAmount.toFixed(2);
  }
}
