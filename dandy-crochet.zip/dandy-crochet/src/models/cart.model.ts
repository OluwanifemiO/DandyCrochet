export class Cart {
  id: number = -1;

  productName: string = "";

  price: number = 0;
  quantity: number = 0;

  totalAmount: number = 0;

  size: string = "";

  imageSrc: string = "";

  productId:number = 1;

  customerId:number = 1;
  constructor(id:number, productName: string, price:number,quantity:number, totalAmount:number, size:string, imageSrc:string, productId:number, customerId:number) {
    this.id = id;
    this.productName = productName;
    this.price = price;
    this.quantity = quantity;
    this.totalAmount = totalAmount;
    this.size = size;
    this.imageSrc = imageSrc;
    this.productId = productId;
    this.customerId = customerId;
  }

}
