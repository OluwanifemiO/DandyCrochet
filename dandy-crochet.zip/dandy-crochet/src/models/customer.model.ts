export class Customer {
  id: number = 1;

  fullName: string = "";

  address: string = "";

  email: string = "";

  phone: string = "";

  city:string = "";

  province: string = "";

  postalCode: string = "";

  country:string = "";

  constructor(fullName: string, address:string, email:string, phone:string, city: string, province: string, postalCode: string, country:string ) {
    this.fullName = fullName;
    this.address = address;
    this.email = email;
    this.phone = phone;
    this.city = city;
    this.province = province;
    this.postalCode = postalCode;
    this.country = country;
  }

}
