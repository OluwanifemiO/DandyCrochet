export class Product {
  id: number = -1;

  productName: string = "";

  price: number = 0;

  description: string = "";

  size: string = "";

  imageSrc: string = "";


  constructor(productName: string, price:number, description: string, size:string, imageSrc:string) {
    this.productName = productName;
    this.price = price;
    this.description = description;
    this.size = size;
    this.imageSrc = imageSrc;
  }

}
