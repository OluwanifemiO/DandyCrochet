export class Order {
  id: number = 1;

  cartId: number = 1;

  totalAmount: number = 0;

  shippingAddress: string = "";

  productName: string = "";

  constructor(cartId:number, totalAmount:number, shippingAddress:string, productName: string) {
    this.cartId = cartId;
    this.totalAmount = totalAmount;
    this.shippingAddress = shippingAddress;
    this.productName = productName;
  }

}
