import {Injectable} from "@angular/core";
import {Customer} from "../models/customer.model";
import {Order} from "../models/order.model";
import {Product} from "../models/product.model";
import {Cart} from "../models/cart.model";

declare function openDatabase(
  name: string,
  version: string,
  displayName: string,
  size: number,
  creationCallback: any
): any;

@Injectable({
  providedIn: 'root'
})

export class DatabaseService {
  private db: any = null;

  constructor() {

  }

  private static errorHandler(error: any) {
    console.error(`Error: ${error.message}`);
  }

  private createDatabase() {
    let name = "CrochetDatabaseDB";
    let version = "";
    let displayName = "DB for Crochet DB Customer, product and order information";
    let size = 2 * 1024 * 1024;

    function creationCallback() {
      console.log("Success: Database created successfully");
    }

    this.db = openDatabase(name, version, displayName, size, creationCallback);
  }

  private getDatabase(): any {
    if (this.db == null) {
      this.createDatabase();
    }
    return this.db;
  }


  private createTables() {
    function txFunction(tx: any) {
      let sql: string = "CREATE TABLE IF NOT EXISTS customers("
        + "id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, " +
        "fullName VARCHAR(50) NOT NULL, " +
        "address VARCHAR(50) NOT NULL, " +
        "email VARCHAR(50) NOT NULL, " +
        "phone VARCHAR(20) NOT NULL, " +
        "city VARCHAR(20) NOT NULL," +
        "province VARCHAR(20) NOT NULL," +
        "postalCode VARCHAR(20) NOT NULL," +
        "country VARCHAR(20) NOT NULL );";

      let sqlDrop:string = "DROP TABLE products;"
      tx.executeSql(sqlDrop, [], null, (tx: any, error: any) => {
        console.error(`Error dropping Products Table: ${error.message}`);
      });


      let sql2: string = "CREATE TABLE IF NOT EXISTS products("
        + "id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, " +
        "productName VARCHAR(50) NOT NULL, " +
        "price DOUBLE NOT NULL, " +
        "description VARCHAR(50) NOT NULL, " +
        "size VARCHAR(20) NOT NULL, " +
        "imageSrc VARCHAR(200) NULL);";

      let sqlIn:string = "INSERT INTO products(productName, price, description, size, imageSrc) VALUES" +
        "('Check Design Vest', 25.99, 'This is a checkboard design vest with multicolored sleeves and hem.', 'Small', '../../assets/img/Check Mate Sweater Vest 🏁☯️💘✨.jpg'), " +
        "('Off-Shoulder Mesh Top', 14.99, 'This is a black off-shoulder mesh crop top', 'Medium', '../../assets/img/Cropped de crochê modelos para arrasar em 2021.jpg')," +
        "('Colorblock Cami Top', 9.99, 'This is a cami crop top with colorblock design in shades of blue and white.', 'Small', '../../assets/img/Edrianna Crochet 🌺.jpg')," +
        "('Striped Halter Crop Top', 11.99, 'This is a striped halter top in shades of yellow, white and brown.', 'Medium', '../../assets/img/Hooked & Tangled ♡ on Instagram “Time for Stella Top flatlays!! 🌼 This top is definitely one of the prettiest pieces I''ve made and I would like to thank miss Aly of…”.jpg')," +
        "('Cropped Cardigan', 49.99, 'This is a green and white cropped cardigan.', 'Large', '../../assets/img/Minnie Stitches.png')," +
        "('V-Neck Crop Top', 11.99, 'This is a lilac v-neck crop top with a lacy design.', 'Small', '../../assets/img/Stylish and Cute Crochet Top Pattern Ideas for Summer! - Megan Anderson Knittingway_com.jpg')," +
        "('High Neck Halter Crop Top with Belt', 20.99, 'This is a backless high neck halter top with a belt.', 'Large', '../../assets/img/THNLife - Halter Neck Crochet Top Pattern Ulrikke Henninen.gif')," +
        "('Cami Top and Short Set', 49.99, 'This is a set of cami crop top and paperbag waist shorts with belt.', 'Small', '../../assets/img/Unique and decent crochet crop top designs nd patterns for ladies.jpg');";


      let options:any[] = [];


      let sql3: string = "CREATE TABLE IF NOT EXISTS orders("
        + "id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT," +
        "cartId INTEGER NOT NULL, " +
        "totalAmount DOUBLE NOT NULL, " +
        "shippingAddress VARCHAR(50) NOT NULL," +
        "productName VARCHAR(50) NOT NULL," +
        "FOREIGN KEY(productName) REFERENCES products(productName) );";

      let sql4: string = "CREATE TABLE IF NOT EXISTS cart("
        + "id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, " +
        "productName VARCHAR(50) NOT NULL, " +
        "price DOUBLE NOT NULL, " +
        "quantity NUMERIC NOT NULL, " +
        "totalAmount DOUBLE NOT NULL, " +
        "size VARCHAR(20) NOT NULL, " +
        "imageSrc VARCHAR(200) NULL, " +
        "productId INTEGER NOT NULL," +
        "customerId INTEGER NULL, " +
        "FOREIGN KEY(productId) REFERENCES products(id)," +
        "FOREIGN KEY(customerId) REFERENCES customers(id));";


      tx.executeSql(sql, options, () => {
        console.log("Success: Customers Table created successfully;");
      }, (tx: any, error: any) => {
        console.error(`Error creating Customers Table: ${error.message}`);
      });

      tx.executeSql(sql2, options, () => {
        console.log("Success: Products Table created successfully;");
      }, (tx: any, error: any) => {
        console.error(`Error creating Products Table: ${error.message}`);
      });

      tx.executeSql(sqlIn, options, () => {
        console.log("Success: Products Table inserted successfully;");
      }, (tx: any, error: any) => {
        console.error(`Error inserting into Products Table: ${error.message}`);
        console.error(`${error.stack}`);
      });

      tx.executeSql(sql3, options, () => {
        console.log("Success: Orders Table created successfully;");
      }, (tx: any, error: any) => {
        console.error(`Error creating Orders Table: ${error.message}`);
      });

      tx.executeSql(sql4, options, () => {
        console.log("Success: Cart Table created successfully;");
      }, (tx: any, error: any) => {
        console.error(`Error creating Cart Table: ${error.message}`);
      });
    }

    this.getDatabase().transaction(txFunction, DatabaseService.errorHandler, () => {
      console.log("Success: Table creation transaction successful");
    });
  }

  private dropTables() {
    function txFunction(tx: any) {
      let sql = "DROP TABLE IF EXISTS orders;";
      let sql2 = "DROP TABLE IF EXISTS products;";
      let sql3 = "DROP TABLE IF EXISTS customers;";
      let sql4 = "DROP TABLE IF EXISTS cart;";

      let options: any[] = [];

      tx.executeSql(sql, options, () => {
        console.log("Success: Orders Table dropped successfully");
      }, DatabaseService.errorHandler);

      tx.executeSql(sql2, options, () => {
        console.log("Success: Products Table dropped successfully");
      }, DatabaseService.errorHandler);

      tx.executeSql(sql3, options, () => {
        console.log("Success: Customers Table dropped successfully");
      }, DatabaseService.errorHandler);

      tx.executeSql(sql4, options, () => {
        console.log("Success: Cart Table dropped successfully");
      }, DatabaseService.errorHandler);
    }
    this.getDatabase().transaction(txFunction, DatabaseService.errorHandler, () => {
      console.log("Success: Tables drop transaction successful");
    });
  }

  public initDB() {
    try {
      this.createDatabase();
      this.createTables();

    } catch (err: any) {
      console.error(`Error in initDB: ${err.message}`);
    }
  }

  public clearDB() {
    let result = confirm("Really want to clear database?");
    if (result) {
      this.dropTables();
      this.db = null;
      alert("Database cleared");
    }
  }

//Insert for customers
  insertCustomer(customer: Customer): Promise<any> {
    return new Promise((resolve, reject) => {
      function txFunction(tx: any) {
        var sql = "INSERT INTO customers(fullName, address, email, phone, city, province, postalCode, country) VALUES(?, ?, ?, ?, ?, ?, ?, ?)";

        let options = [customer.fullName, customer.address, customer.email, customer.phone, customer.city, customer.province, customer.postalCode, customer.country];

        console.log(tx);
        tx.executeSql(sql, options, (tx: any, results: any) => {

          resolve(results);
          console.log(results);

        }, (err: any) => {
          reject(`Error in insert${err}`)
        });
        console.log(tx);

      }
      this.getDatabase().transaction(txFunction, DatabaseService.errorHandler, () => {
        console.log("Success: Customer insert transaction successful");
      });

    });
  }



  //insert for cart
  insertCart(cart:Cart): Promise<any> {
    return new Promise((resolve, reject) => {
      function txFunction(tx: any) {
        var sql = "INSERT INTO cart(productName, price, quantity, totalAmount, size, imageSrc, productId, customerId) VALUES(?, ?, ?, ?, ?, ?, ?, ?)";


        let options = [cart.productName, cart.price,cart.quantity, cart.totalAmount, cart.size, cart.imageSrc, cart.productId, cart.customerId];

        tx.executeSql(sql, options, (tx: any, results: any) => {

          resolve(results);

        }, (err: any) => {
          reject(`Error in insert${err}`);
          console.log(err.message);
        });
      }

      this.getDatabase().transaction(txFunction, DatabaseService.errorHandler, () => {
        console.log("Success: Cart insert transaction successful");
      });

    });
  }


  //insert for order
  insertOrder(order: Order): Promise<any> {
    return new Promise((resolve, reject) => {
      function txFunction(tx: any) {
        var sql = "INSERT INTO orders(cartId, totalAmount, shippingAddress, productName) VALUES(?,?,?,?)";

        let options = [order.cartId, order.totalAmount, order.shippingAddress, order.productName];

        tx.executeSql(sql, options, (tx: any, results: any) => {

          resolve(results);

        }, (err: any) => {
          reject(`Error in insert${err}`)
        });
      }

      this.getDatabase().transaction(txFunction, DatabaseService.errorHandler, () => {
        console.log("Success: Order insert transaction successful");
      });

    });
  }


  //selectAll for Customer
  selectAllCustomer(): Promise<any>{
    return new Promise((resolve,reject) =>{

      function txFunction(tx:any){
        var sql = "SELECT * FROM customers;";

        let options:any[] = [];

        tx.executeSql(sql, options, (tx: any, results: any) =>{

          let customers: Customer[] = [];

          if(results.rows.length > 0){
            for(let i = 0; i < results.rows.length; i++){
              let row = results.rows[i];
              let aCustomer:Customer = new Customer(row['fullName'], row['address'], row['email'],row['phone'], row['city'], row['province'], row['postalCode'], row['country']);
              aCustomer.id = row['id'];
              console.log(aCustomer);
              customers.push(aCustomer);
            }
            resolve(customers);
          }else{
            resolve(customers);

          }
        }, (err: any) =>{reject(`Error in selectAllCustomer ${err}`)});
      }

      this.getDatabase().transaction(txFunction, DatabaseService.errorHandler, () => {
        console.log("Success: Select All Customer transaction successful");
      });

    });
  }



  //selectAll for Product
  selectAllProduct(): Promise<any>{
    return new Promise((resolve,reject) =>{

      function txFunction(tx:any){
        var sql = "SELECT * FROM products";

        let options:any[] = [];

        tx.executeSql(sql, options, (tx: any, results: any) =>{

          let products: Product[] = [];

          if(results.rows.length > 0){
            for(let i = 0; i < results.rows.length; i++){
              let row = results.rows[i];
              let aProduct:Product = new Product(row['productName'], row['price'], row['description'],row['size'], row['imageSrc']);
              aProduct.id = row['id'];
              console.log(aProduct);
              products.push(aProduct);
            }
            resolve(products);
          }else{
            resolve(products);

          }
        }, (err: any) =>{reject(`Error in selectAllProduct ${err}`)});
      }

      this.getDatabase().transaction(txFunction, DatabaseService.errorHandler, () => {
        console.log("Success: Select All Product transaction successful");
      });

    });
  }

  //selectAll for Cart
  selectAllCart(): Promise<any>{
    return new Promise((resolve,reject) =>{

      function txFunction(tx:any){
        var sql = "SELECT * FROM cart";

        let options:any[] = [];

        tx.executeSql(sql, options, (tx: any, results: any) =>{

          let cart: Cart[] = [];

          if(results.rows.length > 0){
            for(let i = 0; i < results.rows.length; i++){
              let row = results.rows[i];
              let aCart:Cart = new Cart(row['id'], row['productName'], row['price'], row['quantity'], row['totalAmount'],row['size'], row['imageSrc'], row['productId'], row['productId']);
              aCart.id = row['id'];
              console.log(aCart);
              cart.push(aCart);
            }
            resolve(cart);
          }else{
            resolve(cart);

          }
        }, (err: any) =>{reject(`Error in selectAllCart ${err}`)});
      }

      this.getDatabase().transaction(txFunction, DatabaseService.errorHandler, () => {
        console.log("Success: Select All Cart transaction successful");
      });

    });
  }


  //selectAll for Orders
  selectAllOrder(): Promise<any>{
    return new Promise((resolve,reject) =>{

      function txFunction(tx:any){
        var sql = "SELECT * FROM orders";

        let options:any[] = [];

        tx.executeSql(sql, options, (tx: any, results: any) =>{

          let orders: Order[] = [];

          if(results.rows.length > 0){
            for(let i = 0; i < results.rows.length; i++){
              let row = results.rows[i];
              let aOrder:Order = new Order(row['cartId'], row['totalAmount'], row['shippingAddress'], row['productName']);
              aOrder.id = row['id'];
              console.log(aOrder);
              orders.push(aOrder);
            }
            resolve(orders);
          }else{
            resolve(orders);

          }
        }, (err: any) =>{reject(`Error in selectAllOrder ${err}`)});
      }

      this.getDatabase().transaction(txFunction, DatabaseService.errorHandler, () => {
        console.log("Success: Select All Order transaction successful");
      });

    });
  }


  //delete for cart
  deleteCart(cart: Cart): Promise<any> {
    return new Promise((resolve, reject) => {
      function txFunction(tx: any) {
        var sql = "DELETE FROM cart WHERE id=?;";
        // let options: any[] =[];
        let options = [cart.id];

        tx.executeSql(sql, options, (tx: any, results: any) => {
          // notify the caller
          resolve(results);

        }, (err: any) => {
          reject(`Error in delete cart ${err}`)
        });
      }

      this.getDatabase().transaction(txFunction, DatabaseService.errorHandler, () => {
        console.log("Success: delete cart transaction successful");
      });
    });

  }


  //delete for Orders
  deleteOrder(order: Order): Promise<any> {
    return new Promise((resolve, reject) => {
      function txFunction(tx: any) {
        var sql = "DELETE FROM orders WHERE id=?;";
        // let options: any[] =[];
        let options = [order.id];

        tx.executeSql(sql, options, (tx: any, results: any) => {
          // notify the caller
          resolve(results);

        }, (err: any) => {
          reject(`Error in delete order${err}`)
        });
      }

      this.getDatabase().transaction(txFunction, DatabaseService.errorHandler, () => {
        console.log("Success: delete order transaction successful");
      });
    });

  }




  //Select for Product
  selectProduct(id: any): Promise<any> {
    return new Promise((resolve, reject) => {

      function txFunction(tx: any) {
        var sql = "SELECT * FROM products WHERE id=?;";
        let options: any[] = [id];
        console.log(id);
        tx.executeSql(sql, options, (tx: any, results: any) => {

          if (results.rows.length > 0) {
            let row = results.rows[0];
            let aProduct:Product = new Product(row['productName'], row['price'], row['description'],row['size'], row['imageSrc']);
            aProduct.id = row['id'];
            console.log(aProduct);
            resolve(aProduct);
          } else {
            reject("No Product found");

          }

        }, (err: any) => {
          reject(`Error in select product ${err}`)
        });
      }

      this.getDatabase().transaction(txFunction, DatabaseService.errorHandler, () => {
        console.log("Success: Select Product transaction successful");
      });
    });

  }

  //Select for Cart
  selectCart(id: any): Promise<any> {
    return new Promise((resolve, reject) => {

      function txFunction(tx: any) {
        var sql = "SELECT * FROM cart WHERE id=?;";
        let options: any[] = [id];
        tx.executeSql(sql, options, (tx: any, results: any) => {

          if (results.rows.length > 0) {
            let row = results.rows[0];
            let aCart:Cart = new Cart(row['id'], row['productName'], row['price'], row['quantity'], row['totalAmount'],row['size'], row['imageSrc'], row['productId'], row['customerId']);
            aCart.id = row['id'];
            console.log(aCart);
            resolve(aCart);
          } else {
            reject("No Cart found");

          }

        }, (err: any) => {
          reject(`Error in select cart ${err}`)
        });
      }

      this.getDatabase().transaction(txFunction, DatabaseService.errorHandler, () => {
        console.log("Success: Select Cart transaction successful");
      });
    });

  }


  //update for cart
  updateCart(cart: Cart): Promise<any> {
    return new Promise((resolve, reject) => {
      function txFunction(tx: any) {
        var sql = "UPDATE cart SET productName = ?, price = ?, quantity = ?, totalAmount = ?, size = ?, imageSrc = ?, productId = ?, customerId = ? WHERE id=?;";
        // let options: any[] =[];

        //destructuring
        // let {id, name, price} = book;

        let options = [cart.productName, cart.price, cart.quantity, cart.totalAmount, cart.size, cart.imageSrc, cart.productId, cart.customerId, cart.id];

        console.log(options);

        tx.executeSql(sql, options, (tx: any, results: any) => {
          // notify the caller
          resolve(results);

        }, (err: any) => {
          reject(`Error in update cart ${err.message}`);
          console.log(err.message);
        });
      }

      this.getDatabase().transaction(txFunction, DatabaseService.errorHandler, () => {
        console.log("Success: update cart transaction successful");
      });
    });
  }


  updateCartCustomerId(customerId:number, cartId:number): Promise<any> {
    return new Promise((resolve, reject) => {
      function txFunction(tx: any) {
        var sql = "UPDATE cart SET customerId = ? WHERE id=?;";
        // let options: any[] =[];

        //destructuring
        // let {id, name, price} = book;

        let options = [customerId, cartId];

        console.log(options);

        tx.executeSql(sql, options, (tx: any, results: any) => {
          // notify the caller
          resolve(results);

        }, (err: any) => {
          reject(`Error in update cart customer id ${err.message}`);
          console.log(err.message);
        });
      }

      this.getDatabase().transaction(txFunction, DatabaseService.errorHandler, () => {
        console.log("Success: update cart customer id transaction successful");
      });
    });
  }


}
